﻿namespace askiapp.Model
{
    public class Constants
    {
        public const string SecretKey = "_12Ga3%acb!!asKT5.As&-'*!.@aiHf.ayGP0+2.1:@_5:faRAsGHL14!Esa%%1rAb_S1tadg31ASHKaS_m_!a@sgE&!gadg!+%66+!rga52rh2eTg214gTQt4qt4T+Qrtet134t4";
        public class StorageVariables
        {
            public const string Token = "G%.1%-*4g.63_.14!";
            public const string LoggedAccount = "a%1.6-q4!+.fgLTq@rT";
        }
    }
}
