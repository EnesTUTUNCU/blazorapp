﻿namespace askiapp.Model.Requests
{
    public class MerchantLogin
    {
        public string Account { get; set; }
        public string Password { get; set; }
    }
}
